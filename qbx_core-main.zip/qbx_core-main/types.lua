---@meta

---@class ErrorResult
---@field code string
---@field message string